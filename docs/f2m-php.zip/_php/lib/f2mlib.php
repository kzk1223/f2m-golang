<?php
class f2mlib{

	//----------------------------------------------------
	// ���t�@�C���ǂݍ���
	//
	//----------------------------------------------------
	function perseConfig( $file ){

		$conf		= array();
		$conf_id 	= "";

		//$file = file( "f2m_conf.txt" );
		foreach( file( $file ) as $rec ){

			$rec = mb_convert_encoding($rec , PGM_CHARSET ,"SJIS" );


			if( preg_match( "/^#/" , $rec ) ){
				continue;
			}

			if( preg_match( '/^([^\t:]+)\t*:\t*([^\t\r\n]+)/' , $rec , $match ) ){

				if( $match[1] == "F2M_ID" ){
					$conf_id 			= $match[2];
					$conf[ $conf_id ] 	= array();

				}
				else{
					// �K�{
					if( $match[1] == "F2M_CHK" ){
						$conf[ $conf_id ][ "F2M_CHK" ] = array();
						foreach( explode( "," , $match[2] ) as $fld ){
							$conf[ $conf_id ][ "F2M_CHK" ][ $fld ] = 1;
						}
						
					}
					// email
					else if( $match[1] == "F2M_CHK_EMAIL" ){
						$conf[ $conf_id ][ "F2M_CHK_EMAIL" ] = array();
						foreach( explode( "," , $match[2] ) as $fld ){
							$conf[ $conf_id ][ "F2M_CHK_EMAIL" ][ $fld ] = 1;
						}
						
					}
					// ���{�ꖼ
					else if( $match[1] == "F2M_JPNAME" ){
						$conf[ $conf_id ][ "F2M_JPNAME" ] = array();

						foreach( explode( "," , $match[2] ) as $cmd ){
							if( preg_match( '/^([^:]+):(.+)$/' , $cmd , $m ) ){
								$conf[ $conf_id ][ "F2M_JPNAME" ][ $m[1] ] = $m[2];
							}

						}
						
					}
					// �C�R�[��
					else if( $match[1] == "F2M_CHK_EQ" ){
						$conf[ $conf_id ][ "F2M_CHK_EQ" ] = explode( "," , $match[2] );

						
					}
					// ���̑�
					else{
						$conf[ $conf_id ][ $match[1] ] = $match[2];
					}
				}
			}

			
		}

		//var_dump( $conf );
		//exit;

		return( $conf );


	}


	//----------------------------------------------------
	// 
	//
	//----------------------------------------------------
	function Jpname( $fld  , $config ){
		return( ( isset( $config["F2M_JPNAME"][ $fld ] ) ) ? $config["F2M_JPNAME"][ $fld ] : $fld );

	}


	//----------------------------------------------------
	// 
	//
	//----------------------------------------------------
	function is_email( $email ){
		return( preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $email) );

	}


	//----------------------------------------------------
	// �G���[
	//
	//----------------------------------------------------
	function error( $errmes ){
		printf( '<html><body><b>ERROR:</b>%s</body></html>' , $errmes );

		exit;
	}

	//----------------------------------------------------
	// �e���|�����t�@�C�����擾
	//
	//----------------------------------------------------
	function temporaryFilename( $Dir ){

		mt_srand();

		$fname = sprintf( "%s.%04d", time() , mt_rand( 0, 9999 ) );

		if( file_exists( $Dir."/".$fname ) ){
			$fanme = temporaryFilename( $Dir );
		}

		return( $fname );

	}
	//----------------------------------------------------
	// �e���|�����f�B���N�g�����t���b�V��
	//
	//----------------------------------------------------
	function temporaryDirRefresh( $Dir , $SurvivalSec = 3600 ){

		foreach( glob( $Dir . '/*' ) as $fname ) {
			if( preg_match( '/\d+\.\d{4}$/' , $fname ) ){

				if( ( time() - filemtime($fname) ) > $SurvivalSec ){
					unlink( $fname );
				}
			}

		}

	}

}

?>