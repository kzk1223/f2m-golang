<?php /* Smarty version 2.6.26, created on 2019-06-08 08:39:20
         compiled from index.html */ ?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>お問い合わせ｜シオノケミカル</title>
<meta name="keywords" content="ジェネリック,医薬品,シオノケミカル,原薬,開発,製造">
<meta name="description" content="シオノケミカルへのお問い合せはこちらから。">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
<meta property="og:image" content="http://www.shiono.co.jp/common_new/img/logo.png">
<link rel="stylesheet" href="../common_new/css/default.css" media="all">
<link rel="stylesheet" href="../common_new/css/common.css" media="all">
<link rel="stylesheet" href="../css/form_1708.css" media="all">
<link rel="stylesheet" href="../css/contact.css" media="all">
<script src="../common_new/js/jquery-1.8.2.min.js"></script>
<script src="../common_new/js/jquery.easing.1.3.js"></script>
<script src="../common_new/js/common.js"></script>
<script src="../js/form.js"></script>
<script src="https://ajaxzip3.github.io/ajaxzip3.js"></script>

<!--[if lt IE 9]>
<script src="../common_new/js/html5shiv.js"></script>
<![endif]-->
<!--[if IE 6]>
<script src="../common_new/js/DD_belatedPNG_0.0.8a-min.js"></script>
<script>DD_belatedPNG.fix('.png');</script>
<![endif]-->
<script>
	$(function(){
		$('#frm1 a.zip').click(function(){
			AjaxZip3.zip2addr('zip1','zip2','addr','addr');
			return false;	
		});
		
		$('#frm2 a.zip').click(function(){
			$('#frm1 input[name="zip1"]').remove();
			$('#frm1 input[name="zip2"]').remove();
			$('#frm1 textarea[name="addr"]').remove();
			AjaxZip3.zip2addr('zip1','zip2','addr','addr');
			return false;	
		});
	});
</script>
</head>
<body class="contact">
<div id="wrapper"><!-- #BeginLibraryItem "/Library/header.lbi" -->	<header id="header">
			<div class="inner clr">
				<div class="left-col">
					<div id="logo">
						<a href="../index.html" class="home">
						<img src="../common_new/img/logo.png" width="115" height="36" alt="SHIONO">
						<h1>Shiono Chemical Co., Ltd.</h1>
						</a>
					</div><!-- /#logo -->
				</div><!-- /.left-col -->
				
				<div class="right-col">
					<nav class="language">
						<ul class="clr">
							<li class="english"><a href="../english/index.html">English</a></li>
						</ul>
					</nav><!-- /.language -->
					
					<nav class="header">
						<ul class="clr">
							<li><a href="../drug/list.html">取扱原薬</a></li>
							<li><a href="../shiono_db/choice.html" target="_blank">医薬品関係者の皆様へ</a></li>
							<li><a href="../knowledge/index.html" target="_blank" class="knowledge">ジェネリック医薬品を知ろう</a></li>
							<li class="last"><a href="../sitemap.html">サイトマップ</a></li>
						</ul>
					</nav><!-- /.header -->
				
					<nav id="gnav">
						<ul class="clr">
							<li class="company"><a href="../company/index.html">会社案内</a></li>
							<li class="drug"><a href="../drug/index.html">原薬</a></li>
							<li class="generic"><a href="../generic/index.html">ジェネリック医薬品</a></li>
							<li class="consulting"><a href="../consulting/index.html">コンサルティング</a></li>
							<li class="recruit"><a href="../recruit/index.html">採用情報</a></li>
							<li class="contact"><a href="index.html">お問い合わせ</a></li>
						</ul>
					</nav><!-- /#ganv -->
				</div><!-- /.right-col -->
				
				<nav class="sp">
					<h3><a class="menu"><img src="../common_new/img/bg-sp-menu.png" width="15" alt="menu"></a></h3>
					<div class="tip"><img src="../common_new/img/bg-menu-tip.png" height="21" alt=""></div>
					<ul class="clr">
						<li class="company"><a href="../company/index.html">会社案内</a></li>
						<li class="drug"><a href="../drug/index.html">原薬</a></li>
						<li class="generic"><a href="../generic/index.html">ジェネリック医薬品</a></li>
						<li class="consulting"><a href="../consulting/index.html">コンサルティング</a></li>
						<li class="recruit"><a href="../recruit/index.html">採用情報</a></li>
						<li class="contact"><a href="index.html">お問い合わせ</a></li>
						<li><a href="../drug/list.html">取扱原薬</a></li>
						<li><a href="../shiono_db/choice.html" target="_blank">医薬品関係者の皆様へ</a></li>
						<li><a href="../knowledge/index.html" target="_blank" class="knowledge">ジェネリック医薬品を知ろう</a></li>
						<li class="last"><a href="../sitemap.html">サイトマップ</a></li>
						<li class="english"><a href="../english/index.html">English</a></li>
					</ul>
				</nav><!-- /.sp -->
				
			</div><!-- /.inner -->
		</header><!-- /#header --><!-- #EndLibraryItem --><div id="body">
			<div id="area-title">
				<div class="area-inner">
					<h2>お問い合わせ</h2>
				</div><!-- /.area-inner -->
			</div><!-- /#area-title -->
			
			<div class="inner">
				
				<section id="sec1" class="pattern1">
					<h3 class="pattern1">お電話でのお問い合わせ</h3>
					
					<div class="section-inner">
						<h4>お問い合わせ先</h4>
						<p class="tel">tel. 03-5202-0213</p>
						<p>受付時間　平日(月～金）9:00～18:00<small>※土・日、祝祭日、弊社休業日を除く</small></p>
						
						
						<table>
							<tr>
								<th>・医療用医薬品情報に関する<br class="portrait-inline">お問い合わせ</th>
								<td>学術情報部</td>
							</tr>
							<tr>
								<th>・原薬に関するお問い合わせ</th>
								<td>医薬営業部</td>
							</tr>
							<tr>
								<th>・採用に関するお問い合わせ、<br class="portrait-inline">その他お問い合わせ</th>
								<td>総務部</td>
							</tr>
						</table>
					</div><!-- /.section-inner -->
				</section><!-- /.pattern1 -->
								
				<section id="sec2" class="pattern1">
					<h3 class="pattern1">フォームからのお問い合わせ</h3>
					<p>当社へのお問い合わせは、下記のフォームに必要事項をご記入の上、送信してください。<br>
お問い合わせの内容に応じて回答に時間を要する場合がございます。あらかじめご了承ください。</p>
					<p>※個人情報の取扱いは、<a href="#privacy">プライバシーポリシー</a>に基づき適切に管理致します。</p>
					<p class="alert"><small>＊</small>は必須項目です。</p>
					
					<form id="frm1" action="f2m_utf8.php" method="post">
					<input name="F2M_ID" type="hidden" id="F2M_ID" value="1">
				
					<table class="form portrait-none">
						<tr>
							<th>お名前<small>＊</small></th>
							<td><input name="name" type="text" class="text width-fit"></td>
						</tr>

						<tr>
							<th>ふりがな<small>＊</small></th>
							<td><input name="kana" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>住所<small>＊</small></th>
							<td>
								<div class="wrap-zip clr">
								<div class="zip">郵便番号<input name="zip1" type="text" maxlength="3" class="text zip1">&nbsp;-&nbsp;<input name="zip2" type="text" maxlength="4" class="text zip2"></div><a href="" class="zip">住所自動入力</a>
								</div>
							<textarea name="addr" cols="10" rows="3"></textarea></td>
						</tr>
						<tr>
							<th>お電話番号<small>＊</small></th>
							<td><input name="tel" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>メールアドレス<small>＊</small></th>
							<td><input name="mail" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>メールアドレス確認用<small>＊</small></th>
							<td><input name="mail2" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>御社名</th>
							<td><input name="company" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>部署名</th>
							<td><input name="group" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>お問い合わせ<small>＊</small></th>
							<td><textarea name="contact" cols="10" rows="10"></textarea></td>
						</tr>
						
					</table>
					
					<div class="area-button portrait-none">
						<a href="" class="check">内容を確認する</a>
					</div><!-- /.area-button -->
					
					</form>
					
					
					<form id="frm2" action="f2m_utf8.php" method="post">
					<input name="F2M_ID" type="hidden" id="F2M_ID" value="1">
					<table class="form portrait-block">
						<tr>
							<th>お名前<small>＊</small></th>
						</tr>
						<tr>
							<td><input name="name" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>ふりがな<small>＊</small></th>
						</tr>
						<tr>
							<td><input name="kana" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>住所<small>＊</small></th>
						</tr>
						<tr>
							<td>
								<div class="wrap-zip clr">
								<div class="zip">郵便番号<input name="zip1" type="text" class="text zip1">&nbsp;-&nbsp;<input name="zip2" type="text" class="text zip2"></div><a href="" class="zip">住所自動入力</a>
								</div>
							<textarea name="addr" cols="10" rows="3"></textarea></td>
						</tr>
						<tr>
							<th>お電話番号<small>＊</small></th>
						</tr>
						<tr>
							<td><input name="tel" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>メールアドレス<small>＊</small></th>
						</tr>
						<tr>
							<td><input name="mail" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>メールアドレス確認用<small>＊</small></th>
						</tr>
						<tr>
							<td><input name="mail2" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>御社名</th>
						</tr>
						<tr>
							<td><input name="company" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>部署名</th>
						</tr>
						<tr>
							<td><input name="group" type="text" class="text width-fit"></td>
						</tr>
						<tr>
							<th>お問い合わせ<small>＊</small></th>
						</tr>
						<tr>
							<td><textarea name="contact" cols="10" rows="10"></textarea></td>
						</tr>
						
					</table>
					
					<div class="area-button portrait-block">
						<a href="" class="check">内容を確認する</a>
					</div><!-- /.area-button -->

					</form>

				
				</section><!-- /.pattern1 -->
			
			</div><!-- /.inner -->
			
			<section id="privacy" class="privacy">
				<h3>シオノケミカル　プライバシーポリシー</h3>
				<p class="privacy_date">2017年6月26日</p>
				<div class="wrap-box">
				<div class="box">
					<p class="privacy_lead">シオノケミカルは、個人情報に関する個人の権利を尊重し、<br>以下の基本方針を定めて厳重に管理いたします。</p>
					<ol class="parent">
						<li class="parent">個人情報の取得・利用について<br><br>
							個人情報の取得にあたっては、その利用目的を明らかにして、適正な方法で取得します。<br>また個人情報の利用は、特定した利用目的の範囲内で、業務の遂行に必要な限りで行うものとします。<br><br>
							＜利用目的＞</p>
							<ol class="child">
								<li>・お客様から商談のお申し込みやお問合せに対してご返答する場合</li>
								<li>・お客様に新たな製品やサービスの情報をご提供する場合</li>
								<li>・お客様のご利用状況やご利用履歴を把握する場合</li>
								<li>・当社の製品やサービスの向上をはかるための分析を行う場合</li>
								<li>・その他、当社の業務活動においてお客様に連絡を取る必要が生じたり、お客様を特定する必要がある場合</li>
							</ol>
						</li>
						<li class="parent">第三者への提供について<br>
						ご本人の事前の同意を得ることなく、個人情報を第三者に提供したり、目的の範囲を越えて利用いたしません。<br>業務を委託するために個人情報を第三者に預託する場合には、適切な監督措置を講じます。<br>ただし、法令により例外として扱うことが認められている場合にはそれに従います。</li>
						<li class="parent">個人情報の共同利用について<br>
						グループ企業間内で当該個人情報を共同利用する場合があります。</li>
						<li class="parent">個人情報の管理について<br>
						シオノケミカルは、個人情報の漏えい、滅失、き損等を防止するため管理体制を整備し、適切なセキュリティ対策を実施します。<br>また、役員及び従業員において当該情報の管理を徹底させ、第三者への漏洩を防ぐべく細心の注意を払います。</li>
						<li class="parent">個人情報の開示、利用停止等について<br>
						ご提供いただいた個人情報の開示、訂正、利用停止、消去等については、ご本人のお申し出により合理的な範囲で適正に対応します。</li>
						<li class="parent">個人情報の取扱についての内容変更<br>
						個人情報の取り扱いに関する内容について変更があった場合は、当該ページ内にて随時告知いたします。</li>
					</ol>
					<!--<p>2013年10月　シオノケミカル株式会社</p>-->
					<h4>〈個人情報開示等お問い合わせ〉</h4>
					<dl>
						<dt>シオノケミカル株式会社　総務部　個人情報開示担当者</dt>
						<dd>〒104-0028　東京都中央区八重洲2丁目10番10号</dd>
						<dd>TEL 03-5202-0213</dd>
					</dl>
				</div><!-- /.box -->
				</div><!-- /.wrap-box -->
			</section><!-- /#privacy -->
			
		</div><!-- /#body --><!-- #BeginLibraryItem "/Library/footer.lbi" -->		<div id="pagetop"><a href="#header"><img src="../common_new/img/btn-pagetop.png" width="21" height="21" alt=""></a></div>
<footer id="footer">
			
			<h6>シオノケミカル株式会社　Shiono Chemical Co., Ltd.</h6>
			<div class="address clr">
				<dl class="left-col">
					<dt><!--本社--></dt>
					<dd class="address">東京都中央区八重洲2丁目10番10号</dd>
					<dd class="tel">TEL 03-5202-0213</dd>
				</dl>
				<dl class="right-col">
					<dt>高崎工場</dt>
					<dd class="address">群馬県藤岡市上大塚1286番地の1</dd>
					<dd class="tel">TEL 0274-24-2130</dd>
				</dl>
			</div><!-- /.address -->
			<p id="copyright"><small>Copyright&copy;Shiono Chemical Co., Ltd. All rights reserved.</small></p>
		</footer><!-- /#footer --><!-- #EndLibraryItem --></div><!-- /#wrapper -->
</body>
</html>