<?php /* Smarty version 2.6.26, created on 2013-10-01 09:33:40
         compiled from _php/mail.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_php/mail.tpl', 4, false),)), $this); ?>
<?php echo $this->_tpl_vars['form']['_all']; ?>

----------------------------------------------------------------------------
IP   : <?php echo $_SERVER['REMOTE_ADDR']; ?>

TIME : <?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, '%Y/%m/%d %H:%M:%S') : smarty_modifier_date_format($_tmp, '%Y/%m/%d %H:%M:%S')); ?>

----------------------------------------------------------------------------