<?php /* Smarty version 2.6.26, created on 2013-10-01 13:55:19
         compiled from formerr.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', 'formerr.html', 110, false),)), $this); ?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>お問い合わせ｜シオノケミカル</title>
<meta name="keywords" content="ジェネリック,医薬品,シオノケミカル,原薬,開発,製造">
<meta name="description" content="シオノケミカルへのお問い合せはこちらから。">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">
<meta property="og:image" content="http://www.shiono.co.jp/common_new/img/logo.png">
<link rel="stylesheet" href="../common_new/css/default.css" media="all">
<link rel="stylesheet" href="../common_new/css/common.css" media="all">
<link rel="stylesheet" href="../css/form.css" media="all">
<link rel="stylesheet" href="../css/contact.css" media="all">
<script src="../common_new/js/jquery-1.8.2.min.js"></script>
<script src="../common_new/js/jquery.easing.1.3.js"></script>
<script src="../common_new/js/common.js"></script>
<script src="../js/form.js"></script>
<script src="http://ajaxzip3.googlecode.com/svn/trunk/ajaxzip3/ajaxzip3.js"></script>
<!--[if lt IE 9]>
<script src="../common_new/js/html5shiv.js"></script>
<![endif]-->
<!--[if IE 6]>
<script src="../common_new/js/DD_belatedPNG_0.0.8a-min.js"></script>
<script>DD_belatedPNG.fix('.png');</script>
<![endif]-->
<script>
	$(function(){
		$('a.zip').click(function(){
			AjaxZip3.zip2addr('zip1','zip2','addr','addr');
			return false;
		});
	});
</script>
</head>
<body class="contact">
<div id="wrapper"><!-- #BeginLibraryItem "/Library/header.lbi" -->	<header id="header">
			<div class="inner clr">
				<div class="left-col">
					<div id="logo">
						<a href="../index.html" class="home">
						<img src="../common_new/img/logo.png" width="115" height="36" alt="SHIONO">
						<h1>Shiono Chemical Co., Ltd.</h1>
						</a>
					</div><!-- /#logo -->
				</div><!-- /.left-col -->
				
				<div class="right-col">
					<nav class="language">
						<ul class="clr">
							<li class="english"><a href="../english/index.html">English</a></li>
						</ul>
					</nav><!-- /.language -->
					
					<nav class="header">
						<ul class="clr">
							<li><a href="../drug/list.html">取扱原薬</a></li>
							<li><a href="../shiono_db/choice.html" target="_blank">医薬品関係者の皆様へ</a></li>
							<li><a href="../knowledge/index.html" target="_blank" class="knowledge">ジェネリック医薬品を知ろう</a></li>
							<li class="last"><a href="../sitemap.html">サイトマップ</a></li>
						</ul>
					</nav><!-- /.header -->
				
					<nav id="gnav">
						<ul class="clr">
							<li class="company"><a href="../company/index.html">会社案内</a></li>
							<li class="drug"><a href="../drug/index.html">原薬</a></li>
							<li class="generic"><a href="../generic/index.html">ジェネリック医薬品</a></li>
							<li class="consulting"><a href="../consulting/index.html">コンサルティング</a></li>
							<li class="recruit"><a href="../recruit/index.html">採用情報</a></li>
							<li class="contact"><a href="index.html">お問い合わせ</a></li>
						</ul>
					</nav><!-- /#ganv -->
				</div><!-- /.right-col -->
				
				<nav class="sp">
					<h3><a class="menu"><img src="../common_new/img/bg-sp-menu.png" width="15" alt="menu"></a></h3>
					<div class="tip"><img src="../common_new/img/bg-menu-tip.png" height="21" alt=""></div>
					<ul class="clr">
						<li class="company"><a href="../company/index.html">会社案内</a></li>
						<li class="drug"><a href="../drug/index.html">原薬</a></li>
						<li class="generic"><a href="../generic/index.html">ジェネリック医薬品</a></li>
						<li class="consulting"><a href="../consulting/index.html">コンサルティング</a></li>
						<li class="recruit"><a href="../recruit/index.html">採用情報</a></li>
						<li class="contact"><a href="index.html">お問い合わせ</a></li>
						<li><a href="../drug/list.html">取扱原薬</a></li>
						<li><a href="../shiono_db/choice.html" target="_blank">医薬品関係者の皆様へ</a></li>
						<li><a href="../knowledge/index.html" target="_blank" class="knowledge">ジェネリック医薬品を知ろう</a></li>
						<li class="last"><a href="../sitemap.html">サイトマップ</a></li>
						<li class="english"><a href="../english/index.html">English</a></li>
					</ul>
				</nav><!-- /.sp -->
				
			</div><!-- /.inner -->
		</header><!-- /#header --><!-- #EndLibraryItem --><div id="body">
			<div id="area-title">
				<div class="area-inner">
					<h2>お問い合わせ</h2>
				</div><!-- /.area-inner -->
			</div><!-- /#area-title -->
			
			<div class="inner">
								
				<section id="sec2" class="pattern1">
					<h3 class="pattern1">フォームからのお問い合わせ</h3>
					
					<h4>[ 入力エラー ]</h4>
					<p>以下の項目が正しく入力されていません。<br>
						[入力画面へ戻る] ボタンをクリックして入力画面に戻り入力をやり直して下さい。</p>
						
					<form action="<?php echo ((is_array($_tmp=$_SERVER['SCRIPT_NAME'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" method="post">
					<input type="hidden" name="mode" value="form" >
					<input type="hidden" name="key" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['send']['key'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" >
					<input type="hidden" name="F2M_ID" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['send']['F2M_ID'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" >	
					<table class="form">
						<?php $_from = $this->_tpl_vars['err']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['e']):
?>
						<tr>
							<th><?php echo ((is_array($_tmp=$this->_tpl_vars['e']['fld'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
</th>
							<td><?php echo ((is_array($_tmp=$this->_tpl_vars['e']['errmes'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
</td>
						</tr>
						<?php endforeach; endif; unset($_from); ?>
					</table>
					<div class="area-button">
					<a href="" class="back">入力画面へ戻る</a>				
					</div><!-- /.area-buton -->		
					</form>
				
				</section><!-- /.pattern1 -->
			
			</div><!-- /.inner -->
			
		
		</div><!-- /#body --><!-- #BeginLibraryItem "/Library/footer.lbi" -->		<div id="pagetop"><a href="#header"><img src="../common_new/img/btn-pagetop.png" width="21" height="21" alt=""></a></div>
<footer id="footer">
			
			<h6>シオノケミカル株式会社　Shiono Chemical Co., Ltd.</h6>
			<div class="address clr">
				<dl class="left-col">
					<dt><!--本社--></dt>
					<dd class="address">東京都中央区八重洲2丁目10番10号</dd>
					<dd class="tel">TEL 03-5202-0213</dd>
				</dl>
				<dl class="right-col">
					<dt>高崎工場</dt>
					<dd class="address">群馬県藤岡市上大塚1286番地の1</dd>
					<dd class="tel">TEL 0274-24-2130</dd>
				</dl>
			</div><!-- /.address -->
			<p id="copyright"><small>Copyright&copy;Shiono Chemical Co., Ltd. All rights reserved.</small></p>
		</footer><!-- /#footer --><!-- #EndLibraryItem --></div><!-- /#wrapper -->
</body>
</html>