<?php
//----------------------------------------------------
// 実行環境
//
//----------------------------------------------------
define('SMARTY_DIR', './_php/lib/Smarty/libs/');
define('PGM_CHARSET', 'UTF-8' );
// JIS-MS
if ( function_exists( 'mb_list_encodings' ) && in_array( 'ISO-2022-JP-MS' , mb_list_encodings() ) ){
	define("JIS_CHARSET"	, 'ISO-2022-JP-MS' );
}
else{
	define("JIS_CHARSET"	, 'JIS' );
}

define('DEFAULT_MAIL_TMPL'		, '_php/mail.tpl' );
define('DEFAULT_RESV_MAIL_TMPL'	, '_php/resv.tpl' );
define('ATTACH_FILE_DIR'			, '_php/_file' );
define('DEFAULT_ATTACH_FILE_MAX'	, '3M' );
ini_set('session.use_trans_sid'	, '1');
ini_set("session.auto_start"	, '0' );
mb_language("ja");
mb_internal_encoding(PGM_CHARSET);
//----------------------------------------------------
// 
//
//----------------------------------------------------
session_start();
//----------------------------------------------------
// 
//
//----------------------------------------------------
require_once(SMARTY_DIR . 'Smarty.class.php');
require_once('./_php/lib/f2mlib.php');
require_once("./_php/lib/phpmailer/class.phpmailer.php");
//----------------------------------------------------
// 
//
//----------------------------------------------------
function getSmarty(){
	$Smarty = new Smarty();
	$Smarty->template_dir 	= './';
	$Smarty->compile_dir 	= './_php/_tmpl/templates_c/';
	$Smarty->config_dir 	= './_php/_tmpl/configs/';
	$Smarty->cache_dir 		= './_php/_tmpl/cache/';
	$Smarty->left_delimiter = '<!--{';
	$Smarty->right_delimiter = '}-->';
	return $Smarty;
}
//----------------------------------------------------
// 
//
//----------------------------------------------------
$Config_all = f2mlib::perseConfig( "f2m_conf.txt" );
if( ! isset( $_POST["F2M_ID"] ) ){
	f2mlib::error( "F2M_ID nothing" );
}
if( ! isset( $Config_all[ $_POST["F2M_ID"] ] ) ){
	f2mlib::error( "F2M_ID config error" );
}
$Config = $Config_all[ $_POST["F2M_ID"] ];
if( isset( $Config["F2M_SMTP_AUTH"] ) &&  preg_match(  '/^(true|yes|1)$/i' ,$Config["F2M_SMTP_AUTH"] ) ){
	if( (! isset( $Config["F2M_SMTP_USER"] )) || (! isset( $Config["F2M_SMTP_PASSWORD"] )) ){
		f2mlib::error( "F2M_SMTP_USER or F2M_SMTP_PASSWORD nothing" );
	}
}
//----------------------------------------------------
// 添付ファイルディレクトリリフレッシュ
//
//----------------------------------------------------
f2mlib::temporaryDirRefresh( ATTACH_FILE_DIR , 3600 );
//----------------------------------------------------
// 
//
//----------------------------------------------------
if( ! isset( $_POST["mode"] ) ){
	// フォーム内容記憶
	$_SESSION["form"] = array();
	foreach( $Config["F2M_JPNAME"] as  $fld => $kj ){
		if( isset( $_FILES[ $fld ] ) ){
			$_SESSION["form"][ $fld ] =  $_FILES[ $fld ]["name"]; 
		}
		else{
			$_SESSION["form"][ $fld ] =  isset( $_POST[ $fld ] ) ? (  is_array( $_POST[ $fld ] ) ? join( "," , $_POST[ $fld ] ) : $_POST[ $fld ] ) : ""; 
		}
	}

	// エラーチェック
	$err = errorCheck( $_SESSION["form"] , $Config );
	//var_dump( $err );
	if( count( $err ) > 0 ){
		formError( $_SESSION["form"] , $Config , $err );
		exit;
	}
	else{
		//--------------------
		// 添付ファイル保存
		//--------------------
		if( isset( $Config["F2M_ATTACH_FLD"] ) && $Config["F2M_ATTACH_FLD"] != "" ){
			$_SESSION["attach_file"] = array();
			foreach( split( "," , $Config["F2M_ATTACH_FLD"] ) as $f ){
				if( isset( $_FILES[ $f ] ) && $_FILES[ $f ][ "size" ] > 0 ){
					$fname = f2mlib::temporaryFilename( ATTACH_FILE_DIR );
					//var_dump($fname);
					if ( move_uploaded_file( $_FILES[ $f ]["tmp_name"] , sprintf( "%s/%s" , ATTACH_FILE_DIR ,  $fname )  ) ){
						//var_dump( $_FILES[ $f ] );
						$_SESSION["attach_file"][ $f ] 			 	= $_FILES[ $f ];
						$_SESSION["attach_file"][ $f ][ 'fname' ] 	= $fname;
					}
					else{
						echo "file upload errorr !!";
						exit;
					}
				}
			}
		}

		//--------------------
		// 
		//--------------------
		formConfirm( $_SESSION["form"] , $Config );
		exit;
	}
}
//---------------
// 送信
//---------------
else if( $_POST["mode"] == "send" ){
	// 戻りチェック
	foreach( array_keys($_POST) as $fld ){
		if( preg_match( "/^F2M_RET/" , $fld ) ){
			// 戻り
			form( $_SESSION["form"] , $Config );
			exit;
		}
	}
	// エラーチェック
	$err = errorCheck( $_SESSION["form"] , $Config );
	if( count( $err ) > 0 ){
		formError( $_SESSION["form"] , $Config , $err );
		exit;
	}
	// 送信キーチェック
	if( crypt( $_SESSION["key"] , $_POST["key"] ) != $_POST["key"] ){
		echo "送信エラー";
		exit;
	}
	// 送信
	if( isset( $Config["F2M_TO"] ) && $Config["F2M_TO"] != "" ){
		sendMail( $_SESSION["form"] , $Config );
	}
	// 自動返信
	if( isset( $Config["F2M_RESV_TO_FLD"] ) ){
		sendResvMail( $_SESSION["form"] , $Config );
	}
	// CSV
	if( isset( $Config["F2M_CSV"] ) ){
		putCsv( $_SESSION["form"] , $Config );
	}

	// 送信後画面
	formThx( $_POST , $Config );
}
//---------------
// フォーム
//---------------
else if( $_POST["mode"] == "form" ){
	form( $_SESSION["form"] , $Config );
}
//----------------------------------------------------
// フォーム表示
//
//----------------------------------------------------
function form( $post , $config  ){
	//var_dump( $err );
	//var_dump( $post );
	$Smarty = getSmarty();
	$html = $Smarty->fetch( $config["F2M_FORM"] );
	$html = mb_convert_encoding( $html , "UTF-8" , PGM_CHARSET );

	foreach( $post as  $fld => $kj ){
		$post[ $fld ] = mb_convert_encoding( $post[ $fld ]  , "UTF-8" , PGM_CHARSET );
	}

	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){

		if( preg_match_all( sprintf( '/<input[^>]+name=[\'"]%s(\[\])*[\'"][^>]+/ims' , $fld ) , $html , $matchs , PREG_SET_ORDER  ) ){
			//var_dump( $m );
			foreach( $matchs as $m ){
				if( preg_match( '/type=[\'"]text[\'"]/' , $m[0] ) ){
					$replace = sprintf('%s value="%s"' , $m[0] , htmlentities( $post[ $fld ] , ENT_QUOTES ,  "UTF-8" ) );
					$html = str_replace( $m[0] , $replace , $html );
				}
				else if( preg_match( '/type=[\'"]radio[\'"]/' , $m[0] ) ){
					$replace = preg_replace( sprintf( '/(value=[\'"]%s[\'"])/' , $post[ $fld ] ) , '${1} checked' , $m[0] );
					$html = str_replace( $m[0] , $replace , $html );
				}
				else if( preg_match( '/type=[\'"]checkbox[\'"]/' , $m[0] ) ){
					foreach( split( "," , $post[ $fld ] ) as $v ){
						$replace = preg_replace( sprintf( '/(value=[\'"]%s[\'"])/' , $v ) , '${1} checked' , $m[0] );
						$html = str_replace( $m[0] , $replace , $html );
					}
				}
			}
		}

		if( preg_match_all( sprintf( '/<select[^>]+name=[\'"]%s(\[\])*[\'"].+<\/select>/ims' , $fld ) , $html , $matchs , PREG_SET_ORDER  ) ){
			$patterns = array();
			$replaces = array();
			foreach( split( "," , $post[ $fld ] ) as $v ){
				array_push( $patterns , sprintf( '/(<option)(>%s<)/' , preg_quote( $v ,"/") ) );
				array_push( $replaces , '${1} selected${2}' );
				array_push( $patterns , sprintf( '/(<option value=[\'"]%s[\'"])/' , preg_quote( $v ,"/") ) );
				array_push( $replaces , '${1} selected' );
			}
			foreach( $matchs as $m ){

				$replace = preg_replace( $patterns , $replaces , $m[0] );
				$html = str_replace( $m[0] , $replace , $html );
			}
		}
		if( preg_match_all( sprintf( '/(<textarea[^>]+name=[\'"]%s(\[\])*[\'"][^>]*>)[^>]*(<\/textarea>)/ims' , $fld ) , $html , $matchs , PREG_SET_ORDER  ) ){
			//var_dump( $matchs );
			foreach( $matchs as $m ){
				$replace = sprintf('%s%s%s' , $m[1] , htmlentities( $post[ $fld ] , ENT_QUOTES ,  "UTF-8" ), $m[3] );
				$html = str_replace( $m[0] , $replace , $html );
			}
		}
	}
	echo mb_convert_encoding( $html , PGM_CHARSET , "UTF-8" );
}

//----------------------------------------------------
// エラーチェック
//
//----------------------------------------------------
function errorCheck( $post , $config ){
	$err = array();
	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){
		//--------------
		// 必須
		//--------------
		if( isset( $config["F2M_CHK"][ $fld ] ) ){
			// ファイル
			if( isset( $_FILES[ $fld ] ) && $_FILES[ $fld ]["size"] < 1 ){
				array_push( $err , array( "fld" => $kj , "errmes" => "ファイル選択がされていないか、データ容量オーバーのため受信できません。" ));
				continue;
			}
			else{
				// 通常
				if( ! isset( $post[ $fld ] ) ){
					array_push( $err , array( "fld" => $kj , "errmes" => "入力されていません" ));
					continue;
				}
				else if( $post[ $fld ] == "" ){
					array_push( $err , array( "fld" => $kj , "errmes" => "入力されていません" ));
					continue;
				}
			}
		}
		//--------------
		// email
		//--------------
		if( isset( $config["F2M_CHK_EMAIL"][ $fld ] ) && isset( $post[ $fld ] ) && $post[ $fld ] != "" ){
			if( ! f2mlib::is_email( $post[ $fld ] ) ){
				array_push( $err , array( "fld" => $kj , "errmes" => "形式が不正です" ));
				continue;
			}
		}
	}
	//--------------
	// 確認項目
	//--------------
	if( isset( $config["F2M_CHK_EQ"]  ) ){
		foreach( $config["F2M_CHK_EQ"] as  $chk ){
			if( preg_match( "/^([^:]+):(.+)$/" , $chk , $fld ) ){
				if( $post[ $fld[1] ] != $post[ $fld[2] ] ){
					array_push( $err , array( "fld" => f2mlib::Jpname( $fld[1] , $config ) .",". f2mlib::Jpname( $fld[2] , $config )  , "errmes" => "一致しません" ));
				}
			}

		}
	}
	//--------------
	// 添付データ容量
	//--------------
	$maxsize = ( isset( $config["F2M_ATTACH_MAX"]  ) ) ? $config["F2M_ATTACH_MAX"] : DEFAULT_ATTACH_FILE_MAX;
	if( preg_match( '/(\d+)([MK])/' , $maxsize , $m  ) ){
		$maxsize = $m[1] * ( ( $m[2] == "K" ) ? 1024 : (1024 * 1024) );
	}
	if( isset( $config["F2M_ATTACH_FLD"] ) ){
		foreach( split( "," , $config["F2M_ATTACH_FLD"] ) as $fld ){
			if( isset( $_FILES[ $fld ] ) && $_FILES[ $fld ]["size"] > $maxsize ){
				array_push( $err , array( "fld" => f2mlib::Jpname( $fld , $config ) , "errmes" => sprintf( "容量オーバー(%sByteまで)" , ( isset( $config["F2M_ATTACH_MAX"]  ) ) ? $config["F2M_ATTACH_MAX"] : DEFAULT_ATTACH_FILE_MAX) ));
			}
		}
	}

	return( $err );
}
//----------------------------------------------------
// エラーフォーム
//
//----------------------------------------------------
function formError( $post , $config , $err ){
	//var_dump( $err );
	$Smarty = getSmarty();
	//--------------------
	// 
	//--------------------
	$Smarty->assign( "err" , $err );
	//--------------------
	// 
	//--------------------
	$form = array();
	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){
		array_push( $form , array( "fld" => $kj , "val" => isset( $post[ $fld ] ) ? $post[ $fld ] : "" ) );
	}
	$Smarty->assign( "form" , $form );
	//--------------------
	// 送信キー
	//--------------------
	$send = array();
	$key = "1234";
	$send["key"] 		= crypt( $key );
	$send["F2M_ID"] 	= $_POST["F2M_ID"];
	$_SESSION["key"] 	= $key;
	$Smarty->assign( "send" , $send );
	//--------------------
	// 
	//--------------------
	$Smarty->display( $config["F2M_FORMERR"] );
}

//----------------------------------------------------
// 確認画面
//
//----------------------------------------------------
function formConfirm( $post , $config ){
	//var_dump( $err );
	//var_dump( $_SERVER );

	//--------------------
	// 
	//--------------------
	$form = array();
	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){
		array_push( $form , array( "fld" => $kj , "val" => isset( $post[ $fld ] ) ? $post[ $fld ] : "" ) );
	}
	//--------------------
	// 送信キー
	//--------------------
	$send = array();
	$key = "1234";
	$send["key"] 		= crypt( $key );
	$send["F2M_ID"] 	= $_POST["F2M_ID"];
	$_SESSION["key"] 	= $key;
	//--------------------
	// 
	//--------------------
	$Smarty = getSmarty();
	$Smarty->assign( "form" , $form );
	$Smarty->assign( "post" , $post );
	$Smarty->assign( "send" , $send );
	$Smarty->display( $config["F2M_CONFIRM"] );
}
//----------------------------------------------------
// メール送信
//
//----------------------------------------------------
function sendMail( $post , $config ){
	//var_dump( $err );
	//var_dump( $_SERVER );
	mb_language("ja");
	mb_internal_encoding(PGM_CHARSET);
	//--------------------
	// 内容
	//--------------------
	if( isset( $config["F2M_MAIL_TMPL"] ) ){
		$mailbody = mb_convert_encoding( mailBody( $post , $config , $config["F2M_MAIL_TMPL"] ) , "JIS",PGM_CHARSET );
	}
	else{
		$mailbody = mb_convert_encoding(mailBody( $post , $config , DEFAULT_MAIL_TMPL ) , "JIS" , PGM_CHARSET );
	}

	//--------------------
	// 送信
	//--------------------
	$mail = new PHPMailer();
	$mail->CharSet 	= "iso-2022-jp";
	$mail->Encoding = "7bit";
	foreach( explode( "," , $config["F2M_TO"] ) as $to ){
		$mail->AddAddress( $to );
	}

	$mail->From 	= $config["F2M_FROM"];
	$mail->Sender	= $config["F2M_FROM"];
	$mail->FromName = "";
	//$mail->Subject	= mb_encode_mimeheader(mb_convert_encoding($config["F2M_SUBJECT"],"JIS",PGM_CHARSET));
	//$mail->Subject	= mb_encode_mimeheader($config["F2M_SUBJECT"]);
	$mail->Subject	= $config["F2M_SUBJECT"];
	$mail->Body 	= $mailbody;
	//--------------------
	// 添付ファイル
	//--------------------
	if( isset( $config["F2M_ATTACH_FLD"] ) && $config["F2M_ATTACH_FLD"] != "" ){
		foreach( split( "," , $config["F2M_ATTACH_FLD"] ) as $f ){
			if( isset( $_SESSION["attach_file"][ $f ] ) ){
				$fname = sprintf( "%s/%s" , ATTACH_FILE_DIR , $_SESSION["attach_file"][ $f ][ 'fname' ] );
				if( file_exists( $fname ) ){
					$mail->AddAttachment( $fname , mb_convert_encoding( $_SESSION["attach_file"][ $f ][ "name" ] ,"JIS" , PGM_CHARSET ) );
				}
			}
		}
	}
	//--------------------
	// 送信制御
	//--------------------
	if( isset( $config["F2M_MAIL_SENDER"] ) &&  $config["F2M_MAIL_SENDER"] == 'smtp' ){
		$mail->Mailer 		= 'smtp';
		$mail->Host 		= isset( $config["F2M_SMTP_HOST"] ) 	? $config["F2M_SMTP_HOST"] : "localhost";
		$mail->Port 		= isset( $config["F2M_SMTP_PORT"] )  	? $config["F2M_SMTP_PORT"] : "25";

		if( isset( $config["F2M_SMTP_AUTH"] ) &&  preg_match(  '/^(true|yes|1)$/i' ,$config["F2M_SMTP_AUTH"] ) ){
			$mail->SMTPAuth 	= 'true';
			$mail->Username 	= $config["F2M_SMTP_USER"];
			$mail->Password 	= $config["F2M_SMTP_PASSWORD"];
		}
	}
	//--------------------
	// 送信
	//--------------------
	if ($mail->Send()){
		return( true );
	}
	else{
		f2mlib::error( "send mail failed. " . $mail->ErrorInfo  );
		return( false );
	}
/*
	if( mail( $config["F2M_TO"] ,$subject , $mailbody , "From:".$config["F2M_FROM"] ) ){
		return( true );
	}
	else{
		return( false );
	}
*/
}
//----------------------------------------------------
// メール送信
//
//----------------------------------------------------
function sendResvMail( $post , $config ){
	//var_dump( $err );
	//var_dump( $_SERVER );
	mb_language("ja");
	mb_internal_encoding(PGM_CHARSET);
	//--------------------
	// 内容
	//--------------------
	if( isset( $config["F2M_RESV_TMPL"] ) ){
		$mailbody = mb_convert_encoding( mailBody( $post , $config , $config["F2M_RESV_TMPL"] ) , "JIS",PGM_CHARSET );
	}
	else{
		$mailbody = mb_convert_encoding( mailBody( $post , $config , DEFAULT_RESV_MAIL_TMPL ) , "JIS",PGM_CHARSET );
	}
	//--------------------
	// 送信
	//--------------------
	$mail = new PHPMailer();
	$mail->CharSet 		= "iso-2022-jp";
	$mail->Encoding 	= "7bit";
	$mail->AddAddress( $post[ $config["F2M_RESV_TO_FLD"] ] );
	//$mail->AddAddress( "maki@networld-jp.net" );
	//$mail->AddAddress( "info@ikumen-kajidan.net");
	$mail->From 	= $config["F2M_FROM"];
	$mail->Sender	= $config["F2M_FROM"];
	$mail->FromName = "";
	//$mail->Subject	= mb_encode_mimeheader($config["F2M_RESV_SUBJECT"]);
	$mail->Subject	= $config["F2M_RESV_SUBJECT"];
	$mail->Body 	= $mailbody;
	//var_dump( mb_convert_encoding($config["F2M_RESV_SUBJECT"],"JIS",PGM_CHARSET) );
	//exit;
	//--------------------
	// 送信制御
	//--------------------
	if( isset( $config["F2M_MAIL_SENDER"] ) &&  $config["F2M_MAIL_SENDER"] == 'smtp' ){
		$mail->Mailer 		= 'smtp';
		$mail->Host 		= isset( $config["F2M_SMTP_HOST"] ) 	? $config["F2M_SMTP_HOST"] : "localhost";
		$mail->Port 		= isset( $config["F2M_SMTP_PORT"] )  	? $config["F2M_SMTP_PORT"] : "25";

		if( isset( $config["F2M_SMTP_AUTH"] ) &&  preg_match(  '/^(true|yes|1)$/i' ,$config["F2M_SMTP_AUTH"] ) ){
			$mail->SMTPAuth 	= 'true';
			$mail->Username 	= $config["F2M_SMTP_USER"];
			$mail->Password 	= $config["F2M_SMTP_PASSWORD"];
		}
	}
	if ($mail->Send()){
		return( true );
	}
	else{
		f2mlib::error( "send mail failed. " . $mail->ErrorInfo  );
		return( false );
	}
/*
	if( mail( $post[ $config["F2M_RESV_TO_FLD"] ] ,$subject , $mailbody , "From:".$config["F2M_TO"] ) ){
		return( true );
	}
	else{
		return( false );
	}
*/
}
//----------------------------------------------------
// メールフォーマット
//
//----------------------------------------------------
function mailBody( $post , $config  , $tmpl ){
	$Smarty = getSmarty();
	//--------------------
	// 内容
	//--------------------
	$body = array();
	$form = array();
	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){
		$form[ $fld ] = isset( $post[ $fld ] ) ? $post[ $fld ] : "";
		array_push( $body , sprintf( "%s = %s"  , $kj , isset( $post[ $fld ] ) ? $post[ $fld ] : "" ) );
	}
	$form["_all"] = join( "\n" , $body );
	//--------------------
	// 内容
	//--------------------
	$Smarty->assign( "form" , $form );
	if( ! file_exists( $tmpl ) ){
		f2mlib::error( sprintf( "%s not found" , $tmpl ) );
	}
	return( $Smarty->fetch( $tmpl ) );
}

//----------------------------------------------------
// CSV
//
//----------------------------------------------------
function putCsv( $post , $config ){
	//--------------------
	// 内容
	//--------------------
	$fields = array();
	$values	= array();
	foreach( $config["F2M_JPNAME"] as  $fld => $kj ){
		array_push( $fields , mb_convert_encoding( $kj , "SJIS",PGM_CHARSET ) );
		array_push( $values , mb_convert_encoding( isset( $post[ $fld ] ) ? $post[ $fld ] : "" , "SJIS",PGM_CHARSET ) );
	}

	//--------------------
	// 書き出し
	//--------------------
	if( ! file_exists( $config["F2M_CSV"] ) ){
		$fp = fopen( $config["F2M_CSV"] , 'a');
		fputcsv_php4($fp, $fields );
		fclose($fp);
	}

	//--------------------
	// 書き出し
	//--------------------
	$fp = fopen( $config["F2M_CSV"] , 'a');
	fputcsv_php4($fp, $values );
	fclose($fp);
}
//----------------------------------------------------
// CSV
//
//----------------------------------------------------
function fputcsv_php4($handle, $fields)
{
	$new_fields = array();
	foreach ($fields as $value) {
		$value = str_replace('"', '""', $value);
		if (preg_match('/[,"\s]/', $value)) {
			$value = '"' . $value . '"';
		}
		$new_fields[] = $value;
	}
	return fputs($handle, implode(',', $new_fields) . "\n");
}

//----------------------------------------------------
// 送信後
//
//----------------------------------------------------
function formThx( $post , $config ){
	//var_dump( $err );
	//var_dump( $_SERVER );
	$Smarty = getSmarty();

	$Smarty->display( $config["F2M_THANKS"] );
}

?>
